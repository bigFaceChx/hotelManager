package com.service;

public interface adminService {
    public boolean login(String uName, String uPassword);
}
