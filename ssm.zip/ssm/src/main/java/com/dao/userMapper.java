package com.dao;

import com.pojo.user;

import java.util.List;

public interface userMapper {
    public void insertUser(user user);
}
